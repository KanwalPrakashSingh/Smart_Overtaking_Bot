The codes written by

Saurabh Bhola 09005022
Kanwal Prakash Singh 09005031
Abhishek Kabra 09005037
Kapil Dubey 09005038 

as a part of 20112-cs 308 Project titled Smart Overtaking Bot

include

Adaptive_cruise_control.c
It contains the overtaking subroutine of the overtaking bot which checks for the value of left and right sharp sensor to determine the overtaking status.

lcd.c
It is basically used to print on lcd

matlabgrp9.m
This file is to run camera and capture red colour bot and send and input through zigbee to the bot to decide whether it should overtake from the left side or the right side.
