
	else{
		
    	velocity(100,100);
		while(!(Center_white_line >40 && Right_white_line >40 && Left_white_line>40)){
		  Right_white_line =ADC_Conversion(1);
		  Center_white_line = ADC_Conversion(2);
		  Left_white_line =ADC_Conversion(3);
		  print_it();
		  move_left();
			_delay_ms(50);
		}
		forward();					 //Forward moving form right lane toward left lane
		Center_white_line=200;
		while(Center_white_line>40)	 //Forward Till White Line of left Lane not detected
		{
			  for(i=0;i<8;i++)	 //Doing ADC conversion
			  {
			  data_array[i] = ADC_Conversion(i);
			  }
		  Right_white_line =data_array[1];
		  Center_white_line = data_array[2];
		  Left_white_line =data_array[3];
		  Front_Sharp_Sensor=ADC_Conversion(11);
		  print_it();
	      forward();
		}
		forward();	// Correction for white line detection
		_delay_ms(500);
		print_it();
		while(!(Center_white_line <40 && Right_white_line <40 && Left_white_line<40)){
		  Right_white_line =ADC_Conversion(1);
		  Center_white_line = ADC_Conversion(2);
		  Left_white_line =ADC_Conversion(3);
		  print_it();
		  move_right();
			_delay_ms(50);
		}
		stop();
		Right_Sharp_Sensor=ADC_Conversion(13);
		while(time<time_required)  //time required to overtake (time in units)
		{
		  time++;
		  line_follower(63,150);
		}
		while(Right_Sharp_Sensor>80){
			print_sensor(1,1,9);
			line_follower(50,100);//check from right sensor
			Right_Sharp_Sensor=ADC_Conversion(13);
		}
		time=0;
		while(time<time_required)  //time required to overtake (time in units)
		{
		  time++;
		  line_follower(63,150);
		}
		stop();
		velocity(100,100);
		while(!(Center_white_line >40 && Right_white_line >40 && Left_white_line>40)){
		  Right_white_line =ADC_Conversion(1);
		  Center_white_line = ADC_Conversion(2);
		  Left_white_line =ADC_Conversion(3);
		  print_it();
		  move_right();
	    	_delay_ms(50);
		}
		forward();
		Center_white_line=200;
		while(Center_white_line>40)	 //Forward Till White Line of Right Lane not detected
		{
			  for(i=0;i<8;i++)	 //Doing ADC conversion
			  {
			  data_array[i] = ADC_Conversion(i);
			  }
		  Right_white_line =data_array[1];
		  Center_white_line = data_array[2];
		  Left_white_line =data_array[3];
		  Front_Sharp_Sensor=ADC_Conversion(11);
		  print_it();
	      forward();
		}
		forward();	// Correction for white line detection
		_delay_ms(1000);
		while(!(Center_white_line <40 && Right_white_line <40 && Left_white_line<40)){
		  Right_white_line =ADC_Conversion(1);
		  Center_white_line = ADC_Conversion(2);
		  Left_white_line =ADC_Conversion(3);
		  print_it();
		  print_sensor(1,1,1);
		  move_left();
			_delay_ms(50);
		}
	}
